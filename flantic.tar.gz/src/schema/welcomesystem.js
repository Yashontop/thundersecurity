const mongoose = require("mongoose");

const Schema = new mongoose.Schema({
  _id: {
    type: String,
    required: true,
  },
  data: {
    name: String,
    region: String,
    owner: {
      id: String,
      tag: String,
    },
    joinedAt: Date,
    leftAt: Date,
    bots: {
      type: Number,
      default: 0,
    },
  },
  welcome: {
    autodel: {
      type: Number,
      default: 0,
    },
    enabled: {
      type: Boolean,
      default: false,
    },
    channel: String,
    content: String,
    embed: {
      image: {
        type: String,
        default: "",
      },
      description: String,
      color: String,
      title: String,
      thumbnail: {
        type: String,
        default: "",
      },
      footer: String,
    },
  },
});

const Model = mongoose.model("guild", Schema);

module.exports = {
  /**
   * guildOrId: Discord Guild object or guild ID string
   * client: optional, required if passing only ID and you want to fetch guild for metadata
   */
  getSettings: async (guildOrId, client = null) => {
    let guildId;
    let guildObj = null;

    if (typeof guildOrId === "string") {
      guildId = guildOrId;
      if (client) {
        try {
          guildObj = await client.guilds.fetch(guildId);
        } catch (e) {
          console.log("[getSettings] failed to fetch guild from client:", e);
        }
      }
    } else if (guildOrId && guildOrId.id) {
      guildObj = guildOrId;
      guildId = guildOrId.id;
    } else {
      console.log("[getSettings] invalid input, neither guild object nor string ID:", guildOrId);
      throw new Error("Invalid guild identifier passed to getSettings");
    }

    let guildData = await Model.findOne({ _id: guildId });
    if (!guildData) {
      let ownerTag = null;
      let ownerId = null;

      if (guildObj) {
        ownerId = guildObj.ownerId;
        try {
          const owner = await guildObj.fetchOwner();
          ownerTag = owner?.user?.tag || null;
        } catch (e) {
          console.log("[getSettings] failed to fetch owner:", e);
        }
      }

      guildData = new Model({
        _id: guildId,
        data: {
          name: guildObj?.name || "Unknown",
          region: guildObj?.preferredLocale || "unknown",
          owner: {
            id: ownerId || null,
            tag: ownerTag,
          },
          joinedAt: guildObj?.createdAt || new Date(),
        },
      });

      await guildData.save();
    }

    return guildData;
  },
};