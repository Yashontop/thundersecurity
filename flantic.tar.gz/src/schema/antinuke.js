const mongoose = require("mongoose");

const AntiNukeSchema = new mongoose.Schema({
  guildId: {
    type: String,
    required: true,
    unique: true,
  },
  isEnabled: {
    type: Boolean,
    default: false,
  },
  protections: {
    type: [String],
    default: [],
  },
  extraOwners: {
    type: [String],
    default: [],
  },
  whitelistUsers: {
    type: [String],
    default: [],
  },
  whitelistRoles: {
    type: [String],
    default: [],
  },
  userProtections: {
    type: Map,
    of: [String],
    default: {},
  },
  roleProtections: {
    type: Map,
    of: [String],
    default: {},
  },
  logChannelId: {
    type: String,
    default: null,
  },
}, {
  timestamps: true,
});

module.exports = mongoose.model("AntiNuke", AntiNukeSchema);