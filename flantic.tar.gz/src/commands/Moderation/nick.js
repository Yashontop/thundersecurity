/** @format
 *
 * Arrkiii By Ozuma xd
 * © 2024 Arrkiii Development
 *
 */

const {
  EmbedBuilder,
  PermissionsBitField,
} = require("discord.js");

module.exports = {
  name: "nick",
  category: "Moderation",
  aliases: ["nickname", "setnick"],
  cooldown: 3,
  description: "Change a user's nickname",
  args: true,
  usage: "<user> <new nickname>",
  userPerms: ["ManageNicknames"],
  botPerms: ["ManageNicknames"],
  owner: false,

  execute: async (message, args, client, prefix) => {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ManageNicknames)) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | You must have \`Manage Nicknames\` permissions to use this command.`),
        ],
      });
    }

    const member =
      message.mentions.members.first() ||
      message.guild.members.cache.get(args[0]);

    if (!member) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | User not found.`),
        ],
      });
    }

    if (member.id === message.guild.ownerId) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | You can't change the owner's nickname.`),
        ],
      });
    }

    if (member.roles.highest.position >= message.member.roles.highest.position &&
      message.author.id !== message.guild.ownerId) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | You can't change a user with a higher or equal role.`),
        ],
      });
    }

    if (!member.manageable) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | I can't change this user's nickname.`),
        ],
      });
    }

    const newNick = args.slice(1).join(" ");
    if (!newNick) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | Please provide a new nickname.`),
        ],
      });
    }

    try {
      await member.setNickname(newNick);
      return message.channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.tick} | Successfully changed **${member.user.tag}**'s nickname to **${newNick}**.`),
        ],
      });
    } catch (err) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | Failed to change nickname: ${err.message}`),
        ],
      });
    }
  },
};
