const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "embed",
  category: "Utility",
  aliases: [],
  cooldown: 2,
  description: "Send a message as an embed.",
  args: true,
  usage: "<message>",
  userPerms: [],
  botPerms: [],
  owner: false,

  execute: async (message, args, client, prefix) => {
    const content = args.join(" ");
    if (!content) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setTitle("**__Embed Command__**")
            .setDescription(`Usage: \`${prefix}embed <message>\``)
        ]
      });
    }

    // Delete the command message
    await message.delete().catch(() => {});

    // Send the embed
    const embed = new EmbedBuilder()
      .setColor(client.color || "#2f3136")
      .setDescription(content);

    await message.channel.send({ embeds: [embed] });
  }
};
