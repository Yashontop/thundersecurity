/** @format
 *
 * Arrkiii By Ozuma xd
 * © 2024 Arrkiii Development
 *
 */

const {
  EmbedBuilder,
  PermissionsBitField,
} = require("discord.js");

module.exports = {
  name: "warn",
  category: "Moderation",
  aliases: ["warn"],
  cooldown: 3,
  description: "to warn any user",
  args: true,
  usage: "<user> [reason]",
  userPerms: ["ManageMessages"],
  botPerms: ["ManageMessages"],
  owner: false,
  execute: async (message, args, client, prefix) => {
    if (!message.member.permissions.has(PermissionsBitField.resolve("ManageMessages"))) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(
              `${client.emoji.cross} | You must have \`Manage Messages\` permissions to use this command.`
            ),
        ],
      });
    }

    const user =
      message.mentions.members.first() ||
      message.guild.members.cache.get(args[0]);
    let reason = args.slice(1).join(" ") || "No Reason Provided";
    const fullReason = `${message.author.tag} (${message.author.id}) | ${reason}`;

    if (!user) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | User Not Found`),
        ],
      });
    }

    if (user.id === client.user.id) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | You can't warn me.`),
        ],
      });
    }

    if (user.id === message.guild.ownerId) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(
              `${client.emoji.cross} | You can't warn the server owner.`
            ),
        ],
      });
    }

    if (
      user.roles.highest.position >= message.member.roles.highest.position &&
      message.author.id !== message.guild.ownerId
    ) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(
              `${client.emoji.cross} | You can't warn a user with a higher or equal role.`
            ),
        ],
      });
    }

    // Send DM to warned user
    const dmEmbed = new EmbedBuilder()
      .setColor(client.color)
      .setTitle(`You have been warned in ${message.guild.name}`)
      .addFields(
        { name: "Warned By", value: `${message.author.tag}`, inline: true },
        { name: "Reason", value: reason, inline: true },
      )
      .setFooter({ text: `User ID: ${message.author.id}` })
      .setTimestamp();

    try {
      await user.send({ embeds: [dmEmbed] });
    } catch (err) {
      // Fail silently if DMs are closed
    }

    // Send public confirmation message
    const publicEmbed = new EmbedBuilder()
      .setColor(client.color)
      .setTitle(`${client.emoji.tick} User Warned`)
      .addFields(
        { name: "Warned User", value: `${user.user.tag} (${user.id})`, inline: false },
        { name: "Moderator", value: `${message.author.tag} (${message.author.id})`, inline: false },
        { name: "Reason", value: reason, inline: false },
      )
      .setTimestamp();

    return message.channel.send({ embeds: [publicEmbed] });
  },
};
