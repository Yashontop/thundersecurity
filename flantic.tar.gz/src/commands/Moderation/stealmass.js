const { EmbedBuilder } = require("discord.js");
const { default: axios } = require("axios");

module.exports = {
  name: "stealmass",
  category: "Moderation",
  aliases: ["stealmass", "addemojitz"],
  description: "Adds emojis to the server (supports multiple emojis).",
  args: false,
  usage: "<emoji1> [emoji2] [emoji3] ...",
  userPerms: ["ManageEmojisAndStickers"],
  owner: false,

  execute: async (message, args, client) => {
    const prefix = client.prefix || "!";

    const noPerms = new EmbedBuilder()
      .setColor(client.color)
      .setDescription(`${client.emoji.cross} | You must have \`Manage Emoji\` permissions to use this command.`);
    const botNoPerms = new EmbedBuilder()
      .setColor(client.color)
      .setDescription(`${client.emoji.cross} | I need \`Manage Emoji\` permissions to perform this action.`);

    if (!message.member.permissions.has("ManageEmojisAndStickers")) return message.channel.send({ embeds: [noPerms] });
    if (!message.guild.members.me.permissions.has("ManageEmojisAndStickers")) return message.channel.send({ embeds: [botNoPerms] });

    let emojiList = args;
    if (message.reference) {
      const referencedMessage = await message.channel.messages.fetch(message.reference.messageId);
      emojiList = referencedMessage.content.trim().split(/\s+/);
    }

    if (!emojiList.length) {
      return message.channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | Please provide or reply to a message with emojis to add.\nUsage: \`${prefix}stealmass <emoji1> [emoji2]...\``),
        ],
      });
    }

    emojiList = emojiList.slice(0, 99); // Limit to 99 emojis
    let successCount = 0;
    let failed = [];

    const processingEmbed = new EmbedBuilder()
      .setColor(client.color)
      .setTitle(`⏳ | Processing Emoji Upload`)
      .setDescription(`Adding ${emojiList.length} emojis...\n\n✅ Added: 0\n❌ Failed: 0\n⏳ Remaining: ${emojiList.length}`);
    
    const processingMsg = await message.channel.send({ embeds: [processingEmbed] });

    for (let i = 0; i < emojiList.length; i++) {
      let emoji = String(emojiList[i]);
      let name;
      let emojiID, emojiName;
      let url;

      if (emoji.startsWith("<") && emoji.endsWith(">")) {
        const match = emoji.match(/<?a?:?(\w+):(\d+)>?/);
        if (!match) {
          failed.push(emoji);
          continue;
        }
        emojiName = match[1];
        emojiID = match[2];
        name = emojiName;

        const type = await axios
          .get(`https://cdn.discordapp.com/emojis/${emojiID}.gif`)
          .then(() => "gif")
          .catch(() => "png");

        url = `https://cdn.discordapp.com/emojis/${emojiID}.${type}?quality=lossless`;
      } else if (isValidUrl(emoji)) {
        url = emoji;
        name = emoji.split("/").pop().split(".")[0];
      } else {
        failed.push(emoji);
        continue;
      }

      try {
        await message.guild.emojis.create({ attachment: url, name });
        successCount++;
      } catch (e) {
        failed.push(emoji);
      }

      const updatedEmbed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle(`⏳ | Processing Emoji Upload`)
        .setDescription(`Adding ${emojiList.length} emojis...\n\n${client.emoji.tick} Added: ${successCount}\n${client.emoji.cross} Failed: ${failed.length}\n⏳ Remaining: ${emojiList.length - (i + 1)}`);

      await processingMsg.edit({ embeds: [updatedEmbed] });
    }

    const resultEmbed = new EmbedBuilder()
      .setColor(client.color)
      .setTitle(`${client.emoji.tick} | Emoji Add Summary`)
      .addFields(
        { name: `${client.emoji.tick} Successfully Added`, value: `${successCount}`, inline: true },
        { name: `${client.emoji.cross} Failed`, value: `${failed.length}`, inline: true },
        { name: `🔢 Total Attempted`, value: `${emojiList.length}`, inline: true }
      );

    if (failed.length > 0) {
      resultEmbed.addFields({ name: "Failed Emojis", value: failed.join(" ") });
    }

    await processingMsg.edit({ embeds: [resultEmbed] });
  },
};

function isValidUrl(string) {
  try {
    new URL(string);
    return true;
  } catch (_) {
    return false;
  }
}
