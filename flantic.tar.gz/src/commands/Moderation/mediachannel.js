const MediaChannel = require("../../schema/mediachannel");

module.exports = {
  name: "mediachannel",
  category: "Media",
  description: "Manage media-only channels",
  usage: "<add|remove|list> [#channel]",
  userPerms: ["Administrator"],
  args: true,
  cooldown: 3,

  execute: async (message, args, client, prefix) => {
    const sub = args[0]?.toLowerCase();
    const guildId = message.guild.id;
    let data = await MediaChannel.findOne({ guildId });
    if (!data) data = new MediaChannel({ guildId, channels: [] });

    switch (sub) {
      case "add": {
        const channel =
          message.mentions.channels.first() ||
          message.guild.channels.cache.get(args[1]);
        if (!channel) {
          return message.reply({
            embeds: [
              new client.embed().d(`Usage: \`${prefix}mediachannel add #channel\``),
            ],
          });
        }
        if (!data.channels.includes(channel.id)) {
          data.channels.push(channel.id);
          await data.save();
          return message.reply({
            embeds: [
              new client.embed().d(`✅ Added ${channel} as a media-only channel.`),
            ],
          });
        } else {
          return message.reply({
            embeds: [
              new client.embed().d(`${channel} is already set as a media-only channel.`),
            ],
          });
        }
      }

      case "remove": {
        const channel =
          message.mentions.channels.first() ||
          message.guild.channels.cache.get(args[1]);
        if (!channel) {
          return message.reply({
            embeds: [
              new client.embed().d(`Usage: \`${prefix}mediachannel remove #channel\``),
            ],
          });
        }
        if (data.channels.includes(channel.id)) {
          data.channels = data.channels.filter((id) => id !== channel.id);
          await data.save();
          return message.reply({
            embeds: [
              new client.embed().d(`✅ Removed ${channel} from media-only channels.`),
            ],
          });
        } else {
          return message.reply({
            embeds: [
              new client.embed().d(`${channel} is not set as a media-only channel.`),
            ],
          });
        }
      }

      case "list": {
        if (data.channels.length === 0) {
          return message.reply({
            embeds: [new client.embed().d("No media-only channels set for this server.")],
          });
        }
        return message.reply({
          embeds: [
            new client.embed()
              .t("📸 Media-Only Channels")
              .d(data.channels.map((id) => `<#${id}>`).join("\n")),
          ],
        });
      }

      default: {
        return message.reply({
          embeds: [
            new client.embed().d(
              `Unknown subcommand. Use \`${prefix}mediachannel <add|remove|list>\`.`
            ),
          ],
        });
      }
    }
  },
};
