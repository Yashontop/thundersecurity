/** @format
 *
 * Arrkiii By Ozuma xd
 * © 2024 Arrkiii Development
 *
 */

const { EmbedBuilder, PermissionsBitField } = require("discord.js");

module.exports = {
  name: "slowmode",
  category: "Moderation",
  aliases: ["sm"],
  cooldown: 3,
  description: "Set slowmode for a channel",
  args: true,
  usage: "<seconds>",
  userPerms: ["ManageChannels"],
  botPerms: ["ManageChannels"],
  owner: false,
  execute: async (message, args, client, prefix) => {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(
              `${client.emoji.cross} | You must have \`Manage Channels\` permission to use this command.`
            ),
        ],
      });
    }

    const seconds = parseInt(args[0]);
    if (isNaN(seconds) || seconds < 0 || seconds > 21600) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(
              `${client.emoji.cross} | Please provide a valid number between **0** and **21600** seconds.`
            ),
        ],
      });
    }

    await message.channel.setRateLimitPerUser(seconds, `${message.author.tag} (${message.author.id})`);

    return message.channel.send({
      embeds: [
        new EmbedBuilder()
          .setColor(client.color)
          .setDescription(
            seconds === 0
              ? `${client.emoji.tick} | Slowmode has been **disabled** for this channel.`
              : `${client.emoji.tick} | Slowmode set to **${seconds}** seconds for this channel.`
          ),
      ],
    });
  },
};
