const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");

module.exports = {
  name: "roleall",
  description: "Assign a role to humans, bots, or all members using buttons",
  category: "Moderation",
  usage: "<role>",
  userPerms: ["ManageRoles"],
  botPerms: ["ManageRoles"],
  execute: async (message, args, client) => {
    const role = message.mentions.roles.first() ||
      message.guild.roles.cache.find(
        (r) => r.name.toLowerCase() === args.join(" ").toLowerCase()
      ) ||
      message.guild.roles.cache.get(args[0]);

    if (!role) {
      const errorEmbed = new EmbedBuilder()
        .setColor("000000")
        .setDescription("<:bitzxier_crosss:1372926051566747668> | Please mention a valid role or provide its ID/name.");
      return message.channel.send({ embeds: [errorEmbed] });
    }

    const confirmEmbed = new EmbedBuilder()
      .setColor(client.color)
      .setTitle("Role Assignment Menu")
      .setDescription(`Choose who should receive the role ${role}`);

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("give_humans")
        .setLabel("Humans")
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId("give_bots")
        .setLabel("Bots")
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId("give_all")
        .setLabel("All Members")
        .setStyle(ButtonStyle.Success)
    );

    const sentMsg = await message.channel.send({
      embeds: [confirmEmbed],
      components: [row],
    });

    const collector = sentMsg.createMessageComponentCollector({
      filter: (i) => i.user.id === message.author.id,
      time: 60000,
    });

    collector.on("collect", async (interaction) => {
      await interaction.deferUpdate();

      const startEmbed = new EmbedBuilder()
        .setColor("000000")
        .setTitle("Role Assignment Started")
        .setDescription(`Assigning role ${role} to selected members...`);
      await message.channel.send({ embeds: [startEmbed] });

      await sentMsg.delete().catch(() => {});

      await message.guild.members.fetch();

      let members;
      if (interaction.customId === "give_humans") {
        members = message.guild.members.cache.filter((m) => !m.user.bot);
      } else if (interaction.customId === "give_bots") {
        members = message.guild.members.cache.filter((m) => m.user.bot);
      } else {
        members = message.guild.members.cache;
      }

      let success = 0;
      let failed = 0;

      for (const member of members.values()) {
        if (!member.roles.cache.has(role.id)) {
          try {
            await member.roles.add(role);
            success++;
          } catch {
            failed++;
          }
        }
      }

      const resultEmbed = new EmbedBuilder()
        .setColor("000000")
        .setTitle("<:bitzxier_tick:1372925987754610739> | Role Assignment Completed")
        .setDescription(
          `> Role: ${role}\n> Targeted: ${members.size} members\n\n<:bitzxier_tick:1372925987754610739> | Success: **${success}**\n<:bitzxier_crosss:1372926051566747668> | Failed: **${failed}**`
        )
        .setFooter({ text: `Requested by ${message.author.tag}` })
        .setTimestamp();

      await message.channel.send({ embeds: [resultEmbed] });

      collector.stop();
    });

    collector.on("end", (_, reason) => {
      if (reason === "time") {
        const timeoutEmbed = new EmbedBuilder()
          .setColor("Red")
          .setDescription("Button interaction timed out. Please try again.");
        message.channel.send({ embeds: [timeoutEmbed] });
      }
    });
  },
};
