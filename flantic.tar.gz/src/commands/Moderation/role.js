const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "role",
  aliases: ["role"],
  cooldown: 3,
  description: "Add or remove a role from a user",
  category: "Moderation",
  usage: "<@user> <role>",
  example: "role @user Member",
  userPerms: ["ManageRoles"],
  botPerms: ["ManageRoles"],
  roleonly: false,

  execute: async (message, args, client) => {
    const role = (await findMatchingRoles(message.guild, args.slice(1).join(" ")))[0];
    const user =
      message.mentions.members.first() ||
      message.guild.members.cache.get(args[0]);

    if (!user) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setAuthor({
              name: "Please mention a user!",
              iconURL: message.author.displayAvatarURL(),
            }),
        ],
      });
    }

    if (!role) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setAuthor({
              name: "Please provide a valid role!",
              iconURL: message.author.displayAvatarURL(),
            }),
        ],
      });
    }

    const hasRole = user.roles.cache.has(role.id);

    try {
      if (hasRole) {
        await user.roles.remove(role);
        return message.channel.send({
          embeds: [
            new EmbedBuilder()
              .setColor(client.color)
              .setDescription(`<:bitzxier_tick:1372925987754610739> | Successfully **Removed** ${role} from ${user}`),
          ],
        });
      } else {
        await user.roles.add(role);
        return message.channel.send({
          embeds: [
            new EmbedBuilder()
              .setColor(client.color)
              .setDescription(`<:bitzxier_tick:1372925987754610739> | Successfully **Added** ${role} to ${user}`),
          ],
        });
      }
    } catch (err) {
      console.error(err);
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("#000000")
            .setDescription(`<:bitzxier_crosss:1372926051566747668> | Something went wrong while updating roles.`),
        ],
      });
    }
  },
};

function findMatchingRoles(guild, query) {
  const ROLE_MENTION = /<?@?&?(\d{17,20})>?/;
  if (!guild || !query || typeof query !== "string") return [];

  const match = query.match(ROLE_MENTION);
  if (match) return [guild.roles.cache.get(match[1])].filter(Boolean);

  const q = query.toLowerCase();
  return guild.roles.cache.filter((r) =>
    [r.name.toLowerCase()].some((name) => name.includes(q)),
  ).map((r) => r);
}
