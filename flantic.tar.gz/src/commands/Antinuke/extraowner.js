const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, ComponentType } = require("discord.js");
const AntiNuke = require("../../schema/antinuke");

module.exports = {
  name: "extraowner",
  aliases: ["eo"],
  category: "Antinuke",
  description: "Manage extra owners for the server",

  execute: async (message, args, client, prefix) => {
    const subcommand = (args[0] || "").toLowerCase();
    const authorId = message.author.id;

    let config = await AntiNuke.findOne({ guildId: message.guild.id }) || new AntiNuke({ guildId: message.guild.id });

    // Only server owner can use
    if (message.author.id !== message.guild.ownerId) {
      return message.reply({
        embeds: [
          new EmbedBuilder().setColor(client.color).setDescription(`${client.emoji.cross} | Only the server **owner** can use this command.`),
        ],
      });
    }

    // --- HELP MENU ---
    if (!subcommand) {
      const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle("Extra Owner Commands")
        .setDescription(
          `**\`${prefix}extraowner add @user\`** — Add a user as an extra owner.\n` +
          `**\`${prefix}extraowner remove @user\`** — Remove a user from extra owners.\n` +
          `**\`${prefix}extraowner list\`** — Show all extra owners.\n` +
          `**\`${prefix}extraowner reset\`** — Remove all extra owners.`
        );

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("eo_add").setLabel("Add").setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId("eo_remove").setLabel("Remove").setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId("eo_list").setLabel("List").setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId("eo_reset").setLabel("Reset").setStyle(ButtonStyle.Secondary)
      );

      const msg = await message.channel.send({ embeds: [embed], components: [row] });

      const collector = msg.createMessageComponentCollector({
        componentType: ComponentType.Button,
        time: 30000,
        filter: (i) => i.user.id === message.author.id,
      });

      collector.on("collect", async (interaction) => {
        if (interaction.customId === "eo_add") {
          return interaction.reply({ content: `Usage: \`${prefix}extraowner add @user\``, ephemeral: true });
        }
        if (interaction.customId === "eo_remove") {
          return interaction.reply({ content: `Usage: \`${prefix}extraowner remove @user\``, ephemeral: true });
        }
        if (interaction.customId === "eo_list") {
          return runList(message, config, client);
        }
        if (interaction.customId === "eo_reset") {
          return runReset(message, config, client);
        }
      });

      return;
    }

    // --- SUBCOMMANDS ---
    if (subcommand === "add") {
      return runAdd(message, args.slice(1), config, client, prefix);
    }
    if (subcommand === "remove") {
      return runRemove(message, args.slice(1), config, client, prefix);
    }
    if (subcommand === "list") {
      return runList(message, config, client);
    }
    if (subcommand === "reset") {
      return runReset(message, config, client);
    }
  },
};

// ===== SUBCOMMAND FUNCTIONS =====

async function runAdd(message, args, config, client, prefix) {
  const user = message.mentions.users.first();
  if (!user) {
    return message.reply({
      embeds: [new EmbedBuilder().setColor(client.color).setDescription(`Usage: \`${prefix}extraowner add @user\``)],
    });
  }

  if (config.extraOwners.includes(user.id)) {
    return message.reply({
      embeds: [new EmbedBuilder().setColor(client.color).setDescription(`${client.emoji.cross} | <@${user.id}> is already an extra owner.`)],
    });
  }

  if (config.extraOwners.length >= 3) {
    return message.reply({
      embeds: [new EmbedBuilder().setColor(client.color).setDescription(`${client.emoji.cross} | You can only assign up to **3 extra owners**.`)],
    });
  }

  config.extraOwners.push(user.id);
  await config.save();

  return message.reply({
    embeds: [new EmbedBuilder().setColor(client.color).setDescription(`${client.emoji.tick} | Added <@${user.id}> as an extra owner.`)],
  });
}

async function runRemove(message, args, config, client, prefix) {
  const user = message.mentions.users.first();
  if (!user) {
    return message.reply({
      embeds: [new EmbedBuilder().setColor(client.color).setDescription(`Usage: \`${prefix}extraowner remove @user\``)],
    });
  }

  if (!config.extraOwners.includes(user.id)) {
    return message.reply({
      embeds: [new EmbedBuilder().setColor(client.color).setDescription(`${client.emoji.cross} | <@${user.id}> is not an extra owner.`)],
    });
  }

  config.extraOwners = config.extraOwners.filter(id => id !== user.id);
  await config.save();

  return message.reply({
    embeds: [new EmbedBuilder().setColor(client.color).setDescription(`${client.emoji.tick} | Removed <@${user.id}> from extra owners.`)],
  });
}

async function runList(message, config, client) {
  const owners = config?.extraOwners || [];

  return message.reply({
    embeds: [
      new EmbedBuilder()
        .setColor(client.color)
        .setTitle("Extra Owners")
        .setDescription(owners.length > 0 ? owners.map(id => `<@${id}>`).join(", ") : "No extra owners assigned."),
    ],
  });
}

async function runReset(message, config, client) {
  if (config.extraOwners.length === 0) {
    return message.reply({
      embeds: [new EmbedBuilder().setColor(client.color).setDescription("No extra owners to reset.")],
    });
  }

  config.extraOwners = [];
  await config.save();

  return message.reply({
    embeds: [new EmbedBuilder().setColor(client.color).setDescription("<:bitzxier_tick:1372925987754610739> | All extra owners have been removed.")],
  });
}
