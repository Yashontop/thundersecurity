
const { EmbedBuilder } = require("discord.js");
const AntiNuke = require("../../schema/antinuke");

module.exports = {
  name: "unwhitelist",
  aliases: ["uwl"],
  category: "Antinuke",
  description: "Remove a user from the whitelist.",
  execute: async (message, args, client, prefix) => {
    const authorId = message.author.id;
    const guildId = message.guild.id;

    const config = await AntiNuke.findOne({ guildId });
    if (!config || !config.whitelistUsers) {
      return message.reply({
        embeds: [new EmbedBuilder().setColor(client.color).setDescription("⚠ No whitelist exists.")],
      });
    }

    const isOwner = message.guild.ownerId === authorId || client.owner === authorId || config.extraOwners?.includes(authorId);
    if (!isOwner) {
      return message.reply({
        embeds: [new EmbedBuilder().setColor(client.color).setDescription(`${client.emoji.cross} | Only server owner or extra owners can use this command.`)],
      });
    }

    const user = message.mentions.users.first();
    if (!user || !config.whitelistUsers.includes(user.id)) {
      return message.reply({
        embeds: [new EmbedBuilder().setColor(client.color).setDescription("That user is not whitelisted.")],
      });
    }

    config.whitelistUsers = config.whitelistUsers.filter(id => id !== user.id);
    await config.save();

    return message.reply({
      embeds: [new EmbedBuilder().setColor(client.color).setDescription(`<:bitzxier_tick:1372925987754610739> | Removed <@${user.id}> from the whitelist.`)],
    });
  },
};
