
const { EmbedBuilder } = require("discord.js");
const AntiNuke = require("../../schema/antinuke");

module.exports = {
  name: "wlisted",
  aliases: ["wl-list"],
  category: "Antinuke",
  description: "Show all whitelisted users.",
  execute: async (message, args, client) => {
    const config = await AntiNuke.findOne({ guildId: message.guild.id });

    const whitelistArray = config?.whitelistUsers || [];

    if (!whitelistArray.length) {
      return message.reply({
        embeds: [new EmbedBuilder().setColor(client.color).setDescription("❌ No users are currently whitelisted.")],
      });
    }

    const userList = whitelistArray.map(id => `<@${id}>`).join(", ");

    return message.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(client.color)
          .setTitle("Whitelisted Users")
          .setDescription(userList),
      ],
    });
  },
};
