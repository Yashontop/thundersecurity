const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ComponentType
} = require("discord.js");
const AntiNuke = require("../../schema/antinuke");

module.exports = {
  name: "antinuke",
  aliases: ["an"],
  category: "Antinuke",
  description: "Manage antinuke settings for the server",

  execute: async (message, args, client) => {
    const subcommand = (args[0] || "").toLowerCase();
    const authorId = message.author.id;

    let config = await AntiNuke.findOne({ guildId: message.guild.id });
    if (!config) {
      config = new AntiNuke({ guildId: message.guild.id });
      await config.save();
    }

    const isAuthorized =
      message.guild.ownerId === authorId ||
      client.owner === authorId ||
      (config.extraOwners || []).includes(authorId);

    if (!isAuthorized) {
      return message.reply({
        embeds: [
          new client.embed()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | Only server owner or extra owners can use this command.`),
        ],
      });
    }

    // --- HELP MENU ---
    if (!subcommand) {
      const embed = new client.embed()
        .setColor(client.color)
        .setTitle("Antinuke Commands")
        .setDescription(
          `Here are the available Antinuke commands:\n\n` +
          `**\`antinuke\`** — Shows this help menu\n` +
          `**\`antinuke enable\`** — Enable antinuke protections\n` +
          `**\`antinuke disable\`** — Disable antinuke protections`
        );

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("an_enable")
          .setLabel("Enable Antinuke")
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId("an_disable")
          .setLabel("Disable Antinuke")
          .setStyle(ButtonStyle.Danger)
      );

      const msg = await message.channel.send({ embeds: [embed], components: [row] });

      const collector = msg.createMessageComponentCollector({
        componentType: ComponentType.Button,
        time: 30000,
        filter: (i) => i.user.id === message.author.id,
      });

      collector.on("collect", async (interaction) => {
        if (interaction.customId === "an_enable") {
          await runEnable(message, config, client);
          interaction.deferUpdate().catch(() => {});
        }
        if (interaction.customId === "an_disable") {
          await runDisable(message, config, client);
          interaction.deferUpdate().catch(() => {});
        }
      });

      return;
    }

    if (subcommand === "enable") {
      return runEnable(message, config, client);
    }
    if (subcommand === "disable") {
      return runDisable(message, config, client);
    }
  },
};

async function runDisable(message, config, client) {
  if (!config.isEnabled) {
    return message.channel.send({
      embeds: [
        new client.embed()
          .setColor(client.color)
          .setDescription(`🚫 Antinuke is already disabled.`),
      ],
    });
  }

  config.isEnabled = false;
  config.protections = [];
  await config.save();

  return message.channel.send({
    embeds: [
      new client.embed()
        .setColor(client.color)
        .setDescription(`<:bitzxier_tick:1372925987754610739> | Antinuke has been **disabled** for this server.`),
    ],
  });
}

async function runEnable(message, config, client) {
  if (config.isEnabled) {
    return message.channel.send({
      embeds: [
        new client.embed()
          .setColor(client.color)
          .setDescription(`<:bitzxier_tick:1372925987754610739> | Antinuke is already enabled for **${message.guild.name}**.`),
      ],
    });
  }

  const allProtections = [
    "anti_role_create", "anti_role_delete", "anti_role_update",
    "anti_channel_create", "anti_channel_delete", "anti_channel_update",
    "anti_ban", "anti_kick", "anti_webhook", "anti_bot",
    "anti_server", "anti_ping", "anti_emoji_delete",
    "anti_emoji_create", "anti_emoji_update", "anti_member_role_update"
  ];

  const embed = new client.embed()
    .setTitle("Select the options you want to enable.")
    .setColor(client.color)
    .setAuthor({
      name: message.author.tag,
      iconURL: message.author.displayAvatarURL({ dynamic: true }),
    });

  const menu = new StringSelectMenuBuilder()
    .setCustomId("antinuke_select")
    .setPlaceholder("Select protections to enable")
    .setMinValues(1)
    .setMaxValues(allProtections.length)
    .addOptions(
      allProtections.map(value => (
        new StringSelectMenuOptionBuilder()
          .setLabel(value.replace(/_/g, " ").replace(/\b\w/g, l => l.toUpperCase()))
          .setValue(value)
      ))
    );

  const allEventsButton = new ButtonBuilder()
    .setCustomId("antinuke_all")
    .setLabel("Enable All Events")
    .setStyle(ButtonStyle.Success);

  const row = new ActionRowBuilder().addComponents(menu);
  const buttonRow = new ActionRowBuilder().addComponents(allEventsButton);

  const msg = await message.channel.send({ embeds: [embed], components: [row, buttonRow] });

  const collector = msg.createMessageComponentCollector({
    componentType: ComponentType.StringSelect,
    time: 60000,
    filter: (i) => i.user.id === message.author.id,
  });

  const buttonCollector = msg.createMessageComponentCollector({
    componentType: ComponentType.Button,
    time: 60000,
    filter: (i) => i.user.id === message.author.id,
  });

  collector.on("collect", async (interaction) => {
    const selected = interaction.values;
    config.isEnabled = true;
    config.protections = selected;
    await config.save();

    await interaction.update({
      embeds: [
        new client.embed()
          .setAuthor({
            name: message.author.tag,
            iconURL: message.author.displayAvatarURL({ dynamic: true }),
          })
          .setColor(client.color)
          .setDescription(
            `**Antinuke has been enabled with the following options:**\n\n` +
            selected.map(p => `<:bitzxier_tick:1372925987754610739> ${p.replace(/_/g, " ").replace(/\b\w/g, l => l.toUpperCase())}`).join("\n")
          )
          .setFooter({ text: message.guild.name })
          .setTimestamp(),
      ],
      components: [],
    });
  });

  buttonCollector.on("collect", async (interaction) => {
    if (interaction.customId === "antinuke_all") {
      config.isEnabled = true;
      config.protections = allProtections;
      await config.save();

      await interaction.update({
        embeds: [
          new client.embed()
            .setAuthor({
              name: message.author.tag,
              iconURL: message.author.displayAvatarURL({ dynamic: true }),
            })
            .setColor(client.color)
            .setDescription(
              `**Antinuke has been enabled with the following options:**\n\n` +
              allProtections.map(p => `<:bitzxier_tick:1372925987754610739> ${p.replace(/_/g, " ").replace(/\b\w/g, l => l.toUpperCase())}`).join("\n")
            )
            .setFooter({ text: message.guild.name })
            .setTimestamp(),
        ],
        components: [],
      });
    }
  });

  collector.on("end", () => {
    if (!collector.collected.size) {
      msg.edit({ content: "Antinuke setup timed out.", components: [] }).catch(() => {});
    }
  });
}
