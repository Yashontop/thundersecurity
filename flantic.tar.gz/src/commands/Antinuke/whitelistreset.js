
const { EmbedBuilder } = require("discord.js");
const AntiNuke = require("../../schema/antinuke");

module.exports = {
  name: "whitelistreset",
  aliases: ["wl-reset"],
  category: "Antinuke",
  description: "Reset the entire whitelist.",
  execute: async (message, args, client) => {
    const authorId = message.author.id;
    const guildId = message.guild.id;

    const config = await AntiNuke.findOne({ guildId });
    const isOwner = message.guild.ownerId === authorId || client.owner === authorId || config?.extraOwners?.includes(authorId);

    if (!isOwner) {
      return message.reply({
        embeds: [new EmbedBuilder().setColor(client.color).setDescription(`${client.emoji.cross} | Only server owner or extra owners can use this command.`)],
      });
    }

    if (!config || config.whitelistUsers.length === 0) {
      return message.reply({
        embeds: [new EmbedBuilder().setColor(client.color).setDescription("⚠ Whitelist is already empty.")],
      });
    }

    config.whitelistUsers = [];
    await config.save();

    return message.reply({
      embeds: [new EmbedBuilder().setColor(client.color).setDescription("<:bitzxier_tick:1372925987754610739> | Whitelist has been reset.")],
    });
  },
};
