
const { EmbedBuilder } = require("discord.js");
const AntiNuke = require("../../schema/antinuke");

module.exports = {
  name: "whitelist",
  aliases: ["wl"],
  category: "Antinuke",
  description: "Add a user to the whitelist.",
  execute: async (message, args, client, prefix) => {
    const authorId = message.author.id;
    const guildId = message.guild.id;

    const config = await AntiNuke.findOne({ guildId }) || new AntiNuke({ guildId });
    const isOwner = message.guild.ownerId === authorId || client.owner === authorId || config.extraOwners?.includes(authorId);

    if (!isOwner) {
      return message.reply({
        embeds: [new EmbedBuilder().setColor(client.color).setDescription(`${client.emoji.cross} | Only server owner or extra owners can use this command.`)],
      });
    }

    const user = message.mentions.users.first();
    if (!user) {
      return message.reply({
        embeds: [new EmbedBuilder().setColor(client.color).setDescription(`Usage: \`${prefix}whitelist @user\``)],
      });
    }

    if (config.whitelistUsers.includes(user.id)) {
      return message.reply({
        embeds: [new EmbedBuilder().setColor(client.color).setDescription(`<@${user.id}> is already whitelisted.`)],
      });
    }

    config.whitelistUsers.push(user.id);
    await config.save();

    return message.reply({
      embeds: [new EmbedBuilder().setColor(client.color).setDescription(`<:bitzxier_tick:1372925987754610739> | Added <@${user.id}> to the whitelist.`)],
    });
  },
};
