const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionsBitField } = require("discord.js");
const { TicketSetup } = require("../../schema/ticket");

module.exports = {
  name: "ticket",
  category: "Ticket",
  description: "Manage the ticket system",
  usage: "ticket <setup/list/reset>",
  userPerms: ["Administrator"],

  execute: async (message, args) => {
    const sub = args[0]?.toLowerCase();
    const filter = m => m.author.id === message.author.id;

    // No subcommand → send help embed
    if (!sub) {
      const embed = new EmbedBuilder()
        .setColor("#000000")
        .setTitle("🎫 Ticket")
        .setDescription(
          "Enhance your server with the Ticket System feature!\n\n" +
          "**Ticket Setup**\nTo Setup Ticket System - `ticket setup`\n\n" +
          "**Ticket List**\nTo List All Ticket Setups - `ticket list`\n\n" +
          "**Ticket Reset**\nTo Reset All Ticket Setups - `ticket reset`"
        )
        .setFooter({ text: "Flantic Ticket" });

      return message.channel.send({ embeds: [embed] });
    }

    // Setup command
    if (sub === "setup") {
      if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator))
        return message.reply("⚠️ You need Administrator permissions.");

      // Ask for panel channel
      await message.channel.send("Please mention the channel for the ticket panel.");
      const collected1 = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
      const panelChannel = collected1.first().mentions.channels.first();
      if (!panelChannel) return message.reply("❌ Invalid channel.");

      // Ask for category
      await message.channel.send("Please enter the category ID where tickets will be created.");
      const collected2 = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
      const categoryId = collected2.first().content.trim();

      // Ask if staff role is needed
      await message.channel.send("Do you want a staff role to manage tickets? (yes or no)");
      const collected3 = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
      const needRole = collected3.first().content.toLowerCase();

      let roleMentions = [];
      if (needRole === "yes") {
        await message.channel.send("Mention the staff role(s) that should have access to tickets.");
        const collected4 = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });
        roleMentions = collected4.first().mentions.roles.map(r => r.id);
      }

      // Ticket panel embed
      const panelEmbed = new EmbedBuilder()
        .setColor("#000000")
        .setTitle("🎫 Ticket Panel")
        .setDescription("Click the button below to create a ticket.")
        .setFooter({ text: "Flantic Ticket Panel" });

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("create_ticket")
          .setLabel("Create Ticket")
          .setStyle(ButtonStyle.Secondary)
      );

      const panelMsg = await panelChannel.send({ embeds: [panelEmbed], components: [row] });

      await TicketSetup.create({
        guildId: message.guild.id,
        channelId: panelChannel.id,
        messageId: panelMsg.id,
        categoryId,
        supportRoles: roleMentions // Empty array if no role chosen
      });

      return message.channel.send("✅ Ticket system has been set up successfully.");
    }

    // List setups
    if (sub === "list") {
      const setups = await TicketSetup.find({ guildId: message.guild.id });
      if (!setups.length) return message.reply("No ticket setups found.");
      return message.channel.send("```" + setups.map(s => `Channel: ${s.channelId} | Message: ${s.messageId}`).join("\n") + "```");
    }

    // Reset setups
    if (sub === "reset") {
      await TicketSetup.deleteMany({ guildId: message.guild.id });
      return message.channel.send("✅ All ticket setups reset.");
    }
  }
};
