module.exports = {
  name: "8ball",
  category: "Fun",
  description: "Ask the magic 8-ball a question",
  usage: "<question>",
  args: true,

  execute: async (message, args, client) => {
    const replies = [
      "Yes.", "No.", "Maybe.", "Definitely!", "Not in a million years.",
      "Ask again later.", "Without a doubt!", "Very unlikely."
    ];
    const result = replies[Math.floor(Math.random() * replies.length)];
    const embed = new client.embed().t("🎱 8-Ball").d(result);
    message.channel.send({ embeds: [embed] });
  },
};
