module.exports = {
  name: "insta",
  category: "Fun",
  description: "Get a random funny Instagram post from Reddit",
  cooldown: 3,

  execute: async (message, args, client) => {
    try {
      const res = await fetch("https://meme-api.com/gimme/Instagramreality");
      const data = await res.json();

      if (!data || !data.url) {
        return message.channel.send({
          embeds: [new client.embed().d("❌ Couldn't fetch a funny post right now!")],
        });
      }

      const embed = new client.embed()
        .t(`📸 ${data.title}`)
        .setImage(data.url)
        .setFooter({ text: `👍 ${data.ups} | r/${data.subreddit}` });

      message.channel.send({ embeds: [embed] });
    } catch (err) {
      console.error(err);
      message.channel.send({
        embeds: [new client.embed().d("❌ Couldn't fetch a funny post right now!")],
      });
    }
  },
};
