module.exports = {
  name: "slap",
  category: "Fun",
  description: "Slap someone",
  usage: "<@user>",

  execute: async (message, args, client) => {
    const member = message.mentions.members.first();
    if (!member) {
      return message.channel.send({
        embeds: [new client.embed().d("❌ You must mention someone to slap!")],
      });
    }

    const gifs = [
      "https://media.tenor.com/4H0l3sK2_lEAAAAC/slap.gif",
      "https://media.tenor.com/XiYuU1MmSssAAAAC/anime-slap.gif",
      "https://media.tenor.com/0hXf1bPq0XwAAAAC/slap.gif"
    ];

    const embed = new client.embed()
      .t("👋 Slap!")
      .d(`${message.author} slapped ${member}!`)
      .setImage(gifs[Math.floor(Math.random() * gifs.length)]);

    message.channel.send({ embeds: [embed] });
  },
};
