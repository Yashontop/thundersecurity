module.exports = {
  name: "cat",
  category: "Fun",
  description: "Get a random cat picture",
  cooldown: 3,

  execute: async (message, args, client) => {
    try {
      const res = await fetch("https://api.thecatapi.com/v1/images/search");
      const data = await res.json();

      const embed = new client.embed()
        .t("🐱 Meow!")
        .setImage(data[0].url);

      message.channel.send({ embeds: [embed] });
    } catch (err) {
      console.error(err);
      message.channel.send({
        embeds: [new client.embed().d("❌ Couldn't fetch a cat picture right now!")],
      });
    }
  },
};
