module.exports = {
  name: "rate",
  category: "Fun",
  description: "Rate anything from 0-100%",
  usage: "<thing>",

  execute: async (message, args, client) => {
    if (!args.length) {
      return message.channel.send({
        embeds: [new client.embed().d("❌ You must provide something to rate!")],
      });
    }
    const rating = Math.floor(Math.random() * 101);
    const embed = new client.embed()
      .t("📊 Rating Machine")
      .d(`I rate **${args.join(" ")}** a solid **${rating}%**`);
    message.channel.send({ embeds: [embed] });
  },
};
