module.exports = {
  name: "say",
  category: "Fun",
  description: "Make the bot say something",
  usage: "<message>",
  args: true,

  execute: async (message, args, client) => {
    const text = args.join(" ");
    const embed = new client.embed().t("🗣️ Message").d(text);
    message.channel.send({ embeds: [embed] });
  },
};
