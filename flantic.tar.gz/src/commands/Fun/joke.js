module.exports = {
  name: "joke",
  category: "Fun",
  description: "Get a random joke (may be NSFW)",
  usage: "",
  cooldown: 3,

  execute: async (message, args, client) => {
    try {
      const res = await fetch("https://v2.jokeapi.dev/joke/Any?type=single");
      const data = await res.json();

      if (!data || !data.joke) {
        return message.channel.send({
          embeds: [new client.embed().d("❌ Could not fetch a joke right now!")],
        });
      }

      const embed = new client.embed().t("😂 Joke Time").d(data.joke);
      message.channel.send({ embeds: [embed] });
    } catch (err) {
      console.error(err);
      message.channel.send({
        embeds: [new client.embed().d("❌ Could not fetch a joke right now!")],
      });
    }
  },
};
