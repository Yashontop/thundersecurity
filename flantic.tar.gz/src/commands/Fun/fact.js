module.exports = {
  name: "fact",
  category: "Fun",
  description: "Get a random fun fact",
  cooldown: 3,

  execute: async (message, args, client) => {
    try {
      const res = await fetch("https://uselessfacts.jsph.pl/random.json?language=en");
      const data = await res.json();

      const embed = new client.embed()
        .t("📚 Random Fact")
        .d(data.text);

      message.channel.send({ embeds: [embed] });
    } catch (err) {
      console.error(err);
      message.channel.send({
        embeds: [new client.embed().d("❌ Couldn't fetch a fact right now!")],
      });
    }
  },
};
