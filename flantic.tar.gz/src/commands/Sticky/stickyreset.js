const Sticky = require('../../schema/sticky');
const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'stickyreset',
  category: 'sticky',
  description: 'Remove all sticky messages in this server.',
  usage: '',
  userPerms: ['ManageGuild'],

  execute: async (message) => {
    const guildId = message.guild.id;

    try {
      const stickies = await Sticky.find({ guildId });
      if (!stickies.length) {
        return message.channel.send({
          embeds: [
            new EmbedBuilder()
              .setColor('Yellow')
              .setDescription('⚠️ No sticky messages found to reset.')
          ]
        });
      }

      for (const s of stickies) {
        const channel = await message.guild.channels.fetch(s.channelId).catch(() => null);
        if (channel?.isTextBased() && s.messageId) {
          const msg = await channel.messages.fetch(s.messageId).catch(() => null);
          if (msg?.deletable) await msg.delete().catch(() => null);
        }
      }

      await Sticky.deleteMany({ guildId });

      message.channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor('Green')
            .setDescription(`✅ Removed all ${stickies.length} sticky messages.`)
        ]
      });
    } catch (err) {
      console.error('stickyreset error:', err);
      message.channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor('Red')
            .setDescription('❌ Something went wrong while resetting stickies.')
        ]
      });
    }
  }
};
