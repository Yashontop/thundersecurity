const Sticky = require('../../schema/sticky');
const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'stickyadd',
  category: 'sticky',
  description: 'Add or update a sticky message in this channel.',
  usage: '<message>',
  userPerms: ['ManageGuild'],

  execute: async (message, args) => {
    if (!args.length) {
      return message.channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor('Yellow')
            .setDescription('⚠️ Usage: `stickyadd <message>`')
        ]
      });
    }

    const content = args.join(' ');
    const channelId = message.channel.id;
    const guildId = message.guild.id;
    const authorId = message.author.id;

    try {
      const existing = await Sticky.findOne({ guildId, channelId });
      if (existing?.messageId) {
        const oldMsg = await message.channel.messages.fetch(existing.messageId).catch(() => null);
        if (oldMsg?.deletable) await oldMsg.delete().catch(() => null);
      }

      const sent = await message.channel.send({ content });

      await Sticky.findOneAndUpdate(
        { guildId, channelId },
        { guildId, channelId, messageId: sent.id, content, authorId, createdAt: new Date() },
        { upsert: true }
      );

      message.channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor('Green')
            .setDescription('✅ Sticky added to this channel.')
        ]
      });
    } catch (err) {
      console.error('stickyadd error:', err);
      message.channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor('Red')
            .setDescription('❌ Something went wrong while adding sticky.')
        ]
      });
    }
  }
};
