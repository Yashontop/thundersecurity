const Sticky = require('../../schema/sticky');
const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'stickylist',
  category: 'sticky',
  description: 'List all sticky messages in this server.',
  usage: '',
  userPerms: ['ManageGuild'],

  execute: async (message) => {
    const guildId = message.guild.id;

    try {
      const stickies = await Sticky.find({ guildId });
      if (!stickies.length) {
        return message.channel.send({
          embeds: [
            new EmbedBuilder()
              .setColor('Yellow')
              .setDescription('⚠️ No sticky messages set in this server.')
          ]
        });
      }

      const embed = new EmbedBuilder()
        .setColor('Blue')
        .setTitle(`📌 Sticky Messages (${stickies.length})`)
        .setDescription(
          stickies
            .map(
              (s, i) =>
                `**${i + 1}.** <#${s.channelId}> — by <@${s.authorId}>\n> ${s.content.substring(0, 100)}`
            )
            .join('\n\n')
        )
        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
        .setTimestamp();

      message.channel.send({ embeds: [embed] });
    } catch (err) {
      console.error('stickylist error:', err);
      message.channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor('Red')
            .setDescription('❌ Something went wrong while listing stickies.')
        ]
      });
    }
  }
};
