const Sticky = require('../../schema/sticky');
const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'stickyremove',
  category: 'sticky',
  description: 'Remove the sticky message from this channel.',
  usage: '',
  userPerms: ['ManageGuild'],

  execute: async (message) => {
    const guildId = message.guild.id;
    const channelId = message.channel.id;

    try {
      const sticky = await Sticky.findOne({ guildId, channelId });
      if (!sticky) {
        return message.channel.send({
          embeds: [
            new EmbedBuilder()
              .setColor('Yellow')
              .setDescription('⚠️ No sticky found for this channel.')
          ]
        });
      }

      if (sticky.messageId) {
        const msg = await message.channel.messages.fetch(sticky.messageId).catch(() => null);
        if (msg?.deletable) await msg.delete().catch(() => null);
      }

      await Sticky.deleteOne({ guildId, channelId });

      message.channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor('Green')
            .setDescription('✅ Sticky removed from this channel.')
        ]
      });
    } catch (err) {
      console.error('stickyremove error:', err);
      message.channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor('Red')
            .setDescription('❌ Something went wrong while removing sticky.')
        ]
      });
    }
  }
};
