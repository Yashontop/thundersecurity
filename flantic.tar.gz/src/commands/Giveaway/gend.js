const Giveaway = require("../../schema/giveaway");

module.exports = {
  name: "gend",
  category: "giveaway",
  description: "End a giveaway early",
  usage: "<messageID>",
  userPerms: ["ManageGuild"],

  execute: async (message, args, client) => {
    const giveaway = await Giveaway.findOne({ messageId: args[0], ended: false });
    if (!giveaway) {
      return message.channel.send({ embeds: [new client.embed().d("No active giveaway found with that message ID.")] });
    }
    giveaway.endAt = new Date();
    await giveaway.save();
    message.channel.send({ embeds: [new client.embed().d("⏹ Giveaway will end shortly.")] });
  }
};
