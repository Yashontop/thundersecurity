const ms = require("ms");
const Giveaway = require("../../schema/giveaway");

module.exports = {
  name: "gstart",
  category: "giveaway",
  description: "Start a giveaway",
  usage: "<time> <winners> <prize>",
  userPerms: ["ManageGuild"],

  execute: async (message, args, client) => {
    if (args.length < 3) {
      return message.channel.send({
        embeds: [new client.embed().d("Usage: `gstart <time> <winners> <prize>`")],
      });
    }

    const time = ms(args[0]);
    const winners = parseInt(args[1]);
    const prize = args.slice(2).join(" ");

    if (!time || winners < 1) {
      return message.channel.send({
        embeds: [new client.embed().d("Invalid time or winners count.")],
      });
    }

    const startAt = new Date();
    const endAt = new Date(Date.now() + time);

    const embed = new client.embed()
      .t(`🎉 Giveaway: ${prize}`)
      .d(`React with 🎉 to enter!\n**Winners:** ${winners}\n**Ends:** <t:${Math.floor(endAt.getTime() / 1000)}:R>`)
      .setFooter({ text: `Hosted by ${message.author.tag}` });

    const msg = await message.channel.send({ embeds: [embed] });
    await msg.react("🎉");

    const giveaway = new Giveaway({
      guildId: message.guild.id,
      channelId: message.channel.id,
      messageId: msg.id,
      prize,
      winnerCount: winners,
      startAt,
      endAt,
      ended: false
    });

    await giveaway.save();

    message.channel.send({
      embeds: [new client.embed().d(`✅ Giveaway started for **${prize}** in ${message.channel}!`)]
    });
  }
};
