// help.js
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  EmbedBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require("discord.js");

module.exports = {
  name: "help",
  category: "utility",
  aliases: ["h"],
  description: "Shows the bot's help menu.",
  cooldown: 3,

  execute: async (message, args, client, prefix) => {
    // Build category map automatically from client.commands (case-insensitive)
    const categoryMap = {};
    client.commands.forEach((cmd) => {
      const cat = (cmd.category || "uncategorized").trim().toLowerCase();
      if (!categoryMap[cat]) categoryMap[cat] = [];
      categoryMap[cat].push(cmd.name);
    });

    // Define main / extra categories
    const mainCategories = [
      { label: "Antinuke", value: "antinuke", emoji: "<:icon_locked:1403346469846650891>" },
      { label: "Auto Moderation", value: "automod", emoji: "<:automod_blaze:1403344809468629002>" },
      { label: "Auto Responder", value: "autoresponder", emoji: "<:icons_forums:1403376608131416225>" },
      { label: "Moderation", value: "moderation", emoji: "<:icon_modshield:1403346347784015922>" },
      { label: "Giveaway", value: "giveaway", emoji: "<:icon_GiveawayIcon:1403346142959505492>" },
      { label: "Ticket", value: "ticket", emoji: "<:icon_ticket:1405438713571577866>" },
      { label: "Utility", value: "utility", emoji: "<:icon_utility:1403346642429673503>" },
      { label: "Welcomer", value: "welcomer", emoji: "<:icons_activityIcon:1403347530682601482>" },
    ];

    const extraCategories = [
      { label: "Auto Reactor", value: "autoreactor", emoji: "<:golu_autoreact:1403346952204062833>" },
      { label: "Custom Roles", value: "customroles", emoji: "<:icons_bulb:1403348032229085245>" },
      { label: "Sticky Message", value: "sticky", emoji: "<:sticky:1403346219803082895>" },
      { label: "Media", value: "media", emoji: "<:media:1403346280570163270>" },
      { label: "Vc Roles", value: "vcroles", emoji: "<:voice:1403348170347646997>" },
      { label: "Fun", value: "fun", emoji: "<:Icon_Star:1403347734593015838>" },
      { label: "Voice Mod", value: "Voice", emoji: "<:voice:1401748851915882616>" },
    ];

    // Main help embed
    const mainEmbed = new EmbedBuilder()
      .setAuthor({ name: `${message.author.username}`, iconURL: client.user.displayAvatarURL() })
      .setDescription(
        `• Prefix: ${prefix}\n• \`${prefix}help <category>\` to view commands of that category.\n\n` +
          `**__Main__**\n` +
          `**<:icon_locked:1403346469846650891> : Antinuke**\n` +
          `**<:automod_blaze:1403344809468629002> : Auto Moderation**\n` +
          `**<:icons_forums:1403376608131416225> : Auto Responder**\n` +
          `**<:icon_modshield:1403346347784015922> : Moderation**\n` +
          `**<:icon_GiveawayIcon:1403346142959505492> : Giveaway**\n` +
          `**<:icon_ticket:1405438713571577866> : Ticket**\n` +
          `**<:icon_utility:1403346642429673503> : Utility**\n` +
          `**<:icons_activityIcon:1403347530682601482> : Welcomer**\n\n` +
          `**__Extra__**\n` +
          `**<:golu_autoreact:1403346952204062833> : Auto Reacotor**\n` +
          `**<:icons_bulb:1403348032229085245> : Custom Roles**\n` +
          `**<:sticky:1403346219803082895> : Sticky Message**\n` +
          `**<:media:1403346280570163270> : Media**\n` +
          `**<:voice:1403348170347646997> : Vc Roles**\n` +
          `**<:Icon_Star:1403347734593015838> : Fun**\n` +
          `**<:voice:1401748851915882616> : Voice Mod**`
      )
      .setThumbnail(client.user.displayAvatarURL())
      .setFooter({ text: "Powered by Flantic HQ", iconURL: client.user.displayAvatarURL() });

    // Rows
    const rowA = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("main_module").setLabel("Main Module").setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId("extra_module").setLabel("Extra Module").setStyle(ButtonStyle.Primary)
    );

    const rowB = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("search_command").setLabel("Search Command").setStyle(ButtonStyle.Secondary)
    );

    const rowC = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId("help_category_select")
        .setPlaceholder("Choose a menu for commands.")
        .addOptions([...mainCategories, ...extraCategories].map((c) => ({
          label: c.label,
          value: c.value.toLowerCase(), // force lowercase for matching
          emoji: c.emoji,
          description: `View ${c.label} commands`,
        })))
    );

    const rowD = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setLabel("Invite Flantic")
        .setStyle(ButtonStyle.Link)
        .setURL(`https://discord.com/oauth2/authorize?client_id=${client.user.id}&scope=bot&permissions=8`),
      new ButtonBuilder()
        .setLabel("Support Server")
        .setStyle(ButtonStyle.Link)
        .setURL("https://discord.gg/bMY4UA6fs9")
    );

    const sent = await message.channel.send({
      embeds: [mainEmbed],
      components: [rowA, rowB, rowC, rowD],
    });

    const collector = sent.createMessageComponentCollector({
      filter: (i) => i.user.id === message.author.id,
      time: 120000,
    });

    const ephemeralHandler = async (i) => {
      try {
        if (i.user.id !== message.author.id) return;

        if (i.isButton() && i.customId.startsWith("cat_")) {
          const cat = i.customId.slice(4).toLowerCase();
          const cmds = categoryMap[cat] || [];
          const embed = new EmbedBuilder()
            .setTitle(`${cat.charAt(0).toUpperCase() + cat.slice(1)} Commands`)
            .setDescription(cmds.length ? cmds.map((c) => `\`${c}\``).join(", ") : "No commands found.")
            .setFooter({ text: `Total ${cmds.length} commands.` });
          return i.reply({ embeds: [embed], ephemeral: true });
        }

        if (i.isModalSubmit() && i.customId === "search_command_modal") {
          const name = i.fields.getTextInputValue("command_name").toLowerCase();
          const cmd =
            client.commands.get(name) || client.commands.find((c) => c.aliases?.includes(name));

          if (!cmd) return i.reply({ content: `❌ Command \`${name}\` not found.`, ephemeral: true });

          const embed = new EmbedBuilder()
            .setTitle(`Command: ${cmd.name}`)
            .setDescription(cmd.description || "No description provided.")
            .addFields(
              { name: "Category", value: cmd.category || "Uncategorized", inline: true },
              { name: "Aliases", value: cmd.aliases?.join(", ") || "None", inline: true },
              { name: "Usage", value: `\`${prefix}${cmd.name}\``, inline: false }
            )
            .setFooter({ text: "Command Search Result" });

          return i.reply({ embeds: [embed], ephemeral: true });
        }
      } catch {}
    };

    client.on("interactionCreate", ephemeralHandler);
    setTimeout(() => client.off("interactionCreate", ephemeralHandler), 120000);

    const chunkButtons = (categories) => {
      const rows = [];
      for (let i = 0; i < categories.length; i += 5) {
        const slice = categories.slice(i, i + 5);
        const row = new ActionRowBuilder();
        row.addComponents(
          ...slice.map((c) =>
            new ButtonBuilder()
              .setCustomId(`cat_${c.value.toLowerCase()}`)
              .setLabel(c.label)
              .setStyle(ButtonStyle.Primary)
              .setEmoji(c.emoji)
          )
        );
        rows.push(row);
      }
      return rows;
    };

    collector.on("collect", async (interaction) => {
      try {
        if (interaction.isButton() && interaction.customId === "main_module") {
          const rows = chunkButtons(mainCategories);
          const embed = new EmbedBuilder()
            .setTitle("Main Module")
            .setDescription("Choose a main category:")
            .setThumbnail(client.user.displayAvatarURL())
            .setFooter({ text: "Only you can see this" });
          return interaction.reply({ embeds: [embed], components: rows, ephemeral: true });
        }

        if (interaction.isButton() && interaction.customId === "extra_module") {
          const rows = chunkButtons(extraCategories);
          const embed = new EmbedBuilder()
            .setTitle("Extra Module")
            .setDescription("Choose an extra category:")
            .setThumbnail(client.user.displayAvatarURL())
            .setFooter({ text: "Only you can see this" });
          return interaction.reply({ embeds: [embed], components: rows, ephemeral: true });
        }

        if (interaction.isButton() && interaction.customId === "search_command") {
          const modal = new ModalBuilder().setCustomId("search_command_modal").setTitle("Search a Command");
          const input = new TextInputBuilder()
            .setCustomId("command_name")
            .setLabel("Enter command name")
            .setStyle(TextInputStyle.Short)
            .setPlaceholder("e.g. ban")
            .setRequired(true);
          modal.addComponents(new ActionRowBuilder().addComponents(input));
          return interaction.showModal(modal);
        }

        if (interaction.isStringSelectMenu() && interaction.customId === "help_category_select") {
          const selected = interaction.values[0].toLowerCase(); // normalize selection
          const cmds = categoryMap[selected] || [];
          const embed = new EmbedBuilder()
            .setTitle(`${selected.charAt(0).toUpperCase() + selected.slice(1)} Commands`)
            .setDescription(cmds.length ? cmds.map((c) => `\`${c}\``).join(", ") : "No commands found.")
            .setFooter({ text: `Total ${cmds.length} commands.` })
            .setThumbnail(client.user.displayAvatarURL());
          return interaction.update({ embeds: [embed], components: [rowA, rowB, rowC, rowD] });
        }
      } catch {
        try {
          if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({ content: "An error occurred.", ephemeral: true });
          }
        } catch {}
      }
    });

    collector.on("end", async () => {
      try {
        await sent.edit({ components: [] });
      } catch {}
      client.off("interactionCreate", ephemeralHandler);
    });
  },
};
