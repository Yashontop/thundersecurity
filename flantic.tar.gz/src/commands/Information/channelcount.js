module.exports = {
  name: "channelcount",
  aliases: ["cc"],
  cooldown: 5,
  category: "Utility",
  execute: async (message, args, client, prefix) => {
    const channelCount = message.guild.channels.cache.size;

    message.reply({
      embeds: [
        new client.embed()
          .setAuthor({
            name: `Channel Count`,
            iconURL: message.guild.iconURL({ dynamic: true }),
          })
          .setDescription(`This server has **${channelCount}** channels!`)
          .setColor("#FF0000")
          .setFooter({
            text: `Requested by ${message.author.tag}`,
            iconURL: message.author.displayAvatarURL(),
          })
          .setTimestamp(),
      ],
    });
  },
};
