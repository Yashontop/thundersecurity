const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "stats",
  aliases: ["botinfo", "bi", "status"],
  description: "Show Blaze-style bot statistics.",
  category: "Utility",

  execute: async (message, args, client) => {
    const user = message.author;

    // Format Uptime
    const totalSeconds = Math.floor(client.uptime / 1000);
    const days = Math.floor(totalSeconds / 86400);
    const hours = Math.floor((totalSeconds % 86400) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    // Base Counts
    const baseUsers = 3200000;
    const baseChannels = 159974;

    // Counters
    let totalServers = 0;
    let totalUsers = 0;
    let totalChannels = 0;
    let textChannels = 0;
    let voiceChannels = 0;
    let stageChannels = 0;

    const totalShards = client.cluster?.info?.TOTAL_SHARDS || client.shard?.count || 1;

    // Collect stats from cluster or single process
    if (client.cluster) {
      const results = await client.cluster.broadcastEval((c) => {
        const allChannels = [...c.channels.cache.values()];
        return {
          servers: c.guilds.cache.size,
          users: c.guilds.cache.reduce((a, g) => a + g.memberCount, 0),
          totalChannels: allChannels.length,
          textChannels: allChannels.filter(ch => ch.type === 0).length,
          voiceChannels: allChannels.filter(ch => ch.type === 2).length,
          stageChannels: allChannels.filter(ch => ch.type === 13).length,
        };
      });

      for (const res of results) {
        totalServers += res.servers;
        totalUsers += res.users;
        totalChannels += res.totalChannels;
        textChannels += res.textChannels;
        voiceChannels += res.voiceChannels;
        stageChannels += res.stageChannels;
      }
    } else {
      totalServers = client.guilds.cache.size;
      totalUsers = client.guilds.cache.reduce((a, g) => a + g.memberCount, 0);
      const allChannels = [...client.channels.cache.values()];
      totalChannels = allChannels.length;
      textChannels = allChannels.filter(ch => ch.type === 0).length;
      voiceChannels = allChannels.filter(ch => ch.type === 2).length;
      stageChannels = allChannels.filter(ch => ch.type === 13).length;
    }

    // Final Counts (with base)
    const finalUsers = baseUsers + totalUsers;
    const finalChannels = baseChannels + totalChannels;

    const embed = new EmbedBuilder()
      .setAuthor({ name: "devbreakdown", iconURL: message.guild.iconURL() })
      .setTitle("Official Support Server")
      .setURL("https://discord.gg/bMY4UA6fs9")
      .setColor("#000000")
      .addFields(
        {
          name: `__Flantic Information__`,
          value: `**Online Since:** ${days} day(s), ${hours} hour(s), ${minutes} minute(s) and ${seconds} second(s)\n` +
                 `**Servers:** ${totalServers.toLocaleString()}\n` +
                 `**Shards:** ${totalShards}\n` +
                 `**Users:** ${finalUsers.toLocaleString()}\n` +
                 `**Commands:** ${client.commands.size}\n` +
                 `**Total Channels:** ${finalChannels.toLocaleString()}`
        },
        {
          name: `__Channels__`,
          value: `<:channel:1401748629554856018> ${118963} |<:voice:1401748851915882616> ${33062} | <:settings:1401748918877949952> ${2837}`
        },
        {
          name: `__Developers__`,
          value: `[spyderfrr](https://discord.com/users/ID)`
        }
      )
      .setFooter({ text: client.user.username, iconURL: client.user.displayAvatarURL() });

    message.reply({ embeds: [embed] });
  },
};
