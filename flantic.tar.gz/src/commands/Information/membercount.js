module.exports = {
  name: "membercount",
  aliases: ["mc"],
  cooldown: 5,
  category: "Utility",
  execute: async (message, args, client, prefix) => {
    const memberCount = message.guild.memberCount;

    message.reply({
      embeds: [
        new client.embed()
          .setAuthor({
            name: `Member Count`,
            iconURL: message.guild.iconURL({ dynamic: true }),
          })
          .setDescription(`This server has **${memberCount}** member(s)!`)
          .setColor("#FF0000")
          .setFooter({
            text: `Requested by ${message.author.tag}`,
            iconURL: message.author.displayAvatarURL(),
          })
          .setTimestamp(),
      ],
    });
  },
};
