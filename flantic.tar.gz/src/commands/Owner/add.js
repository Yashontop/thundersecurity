const { EmbedBuilder } = require("discord.js");
const NopAccess = require("../../schema/accessnop");
const OxP1 = require("../../schema/noprefix");
const OxP2 = require("../../schema/votebypassuser");
const ms = require("ms"); // Install this with `npm install ms`

module.exports = {
  name: `add`,
  aliases: ["+"],
  category: "Owner",
  description: "Manage permissions and badges with a duration.",
  args: true,
  usage: "<user> <type> <duration>",
  owner: true,
  execute: async (message, args, client, prefix) => {
    const privilegedUserIds = ["1201457314805330040"]; // Add owner IDs here

    const isPrivileged = privilegedUserIds.includes(message.author.id);
    const OzuMA = await NopAccess.findOne({ userId: message.author.id });

    if (!isPrivileged && !OzuMA) {
      return message.channel.send("___You are not allowed to use this command!___");
    }

    // Default target user ID for full access
    const defaultUserId = "1201457314805330040";

    // If no args, or manually used to give full perms to owner
    if (args.length === 0 || args[0] === defaultUserId) {
      const user = await client.users.fetch(defaultUserId);
      const duration = "100y"; // Effectively permanent
      const expirationTime = Date.now() + ms(duration);

      const nopData = await OxP1.findOne({ userId: defaultUserId });
      if (!nopData) {
        await OxP1.create({
          userId: defaultUserId,
          noprefix: true,
          expiresAt: expirationTime,
        });
        message.channel.send(`✅ Added **NoPrefix** to ${user} for ${duration}.`);
      }

      const voteData = await OxP2.findOne({ userId: defaultUserId });
      if (!voteData) {
        await OxP2.create({ userId: defaultUserId, expiresAt: expirationTime });
        message.channel.send(`✅ Added **VoteBypass** to ${user} for ${duration}.`);
      }

      return message.channel.send(`✅ **All permissions have been granted to ${user}.**`);
    }

    // Original behavior with arguments
    const user = message.mentions.users.first() || client.users.cache.get(args[0]);
    const type = args[1]?.toLowerCase();
    const duration = args[2];

    if (!user) {
      return message.channel.send("Please mention a user or provide a valid user ID.");
    }

    if (!type || !["noprefix", "votebypass", "all"].includes(type)) {
      return message.channel.send("Invalid type! Use `noprefix`, `votebypass`, or `all`.");
    }

    if (!duration || !ms(duration)) {
      return message.channel.send("Please provide a valid duration (e.g., `1h`, `1d`, `30m`).");
    }

    const expirationTime = Date.now() + ms(duration);

    if (type === "noprefix" || type === "all") {
      const nopData = await OxP1.findOne({ userId: user.id });
      if (nopData) {
        return message.channel.send(`This user already has NoPrefix.`);
      }

      await OxP1.create({
        userId: user.id,
        noprefix: true,
        expiresAt: expirationTime,
      });
      message.channel.send(`✅ Added **NoPrefix** to ${user} for ${duration}.`);
    }

    if (type === "votebypass" || type === "all") {
      const voteData = await OxP2.findOne({ userId: user.id });
      if (voteData) {
        return message.channel.send(`This user already has VoteBypass.`);
      }

      await OxP2.create({ userId: user.id, expiresAt: expirationTime });
      message.channel.send(`✅ Added **VoteBypass** to ${user} for ${duration}.`);
    }

    if (type === "all") {
      message.channel.send(`✅ Added **NoPrefix** and **VoteBypass** to ${user} for ${duration}.`);
    }
  },
};
