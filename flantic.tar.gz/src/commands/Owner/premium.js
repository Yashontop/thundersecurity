const { EmbedBuilder, PermissionsBitField } = require("discord.js");

module.exports = {
  name: "premium",
  category: "Owner",
  description: "Manage Premium features",
  args: true,
  usage: "<add>",
  aliases: [],
  owner: true,

  execute: async (message, args, client) => {
    if (!args[0] || args[0].toLowerCase() !== "add") {
      return message.reply("Usage: `premium add`");
    }

    // Check if the bot has permission to change its nickname
    if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageNicknames)) {
      return message.reply("<:bitzxier_crosss:1372926051566747668> | I don't have permission to change my nickname in this server.");
    }

    try {
      await message.guild.members.me.setNickname("Flantic Prime");

      const embed = new EmbedBuilder()
        .setColor(client.embedColor || "#000000")
        .setDescription("<:bitzxier_tick:1372925987754610739> | Successfully added premium to this Guild ");

      return message.channel.send({ embeds: [embed] });
    } catch (err) {
      console.error("Failed to change nickname:", err);
      return message.reply("<:bitzxier_crosss:1372926051566747668> | Failed to change nickname. Please check my permissions or role position.");
    }
  },
};
