const { EmbedBuilder } = require("discord.js");
const AntiNuke = require("../../schema/antinuke");

module.exports = {
  name: "guildBanAdd",
  run: async (client, ban) => {
    try {
      const data = await AntiNuke.findOne({ guildId: ban.guild.id }).catch(e => {
        console.error("DB error:", e);
        return null;
      });
      if (!data?.isEnabled) return;

      const { extraOwners, whitelistUsers, whitelistRoles, logChannelId } = data;

      await new Promise(res => setTimeout(res, 1000)); // Delay to allow audit log update

      const logs = await ban.guild.fetchAuditLogs({ type: 22, limit: 1 }).catch(e => {
        console.error("Fetch audit logs error:", e);
        return null;
      });
      const entry = logs?.entries.first();

      // Ensure audit log entry matches the banned user
      if (!entry || entry.target.id !== ban.user.id) return;

      const executor = entry.executor;
      if (!executor) return;

      if ([ban.guild.ownerId, client.user.id, ...extraOwners].includes(executor.id)) return;

      const member = await ban.guild.members.fetch(executor.id).catch(e => {
        console.error("Fetch executor member error:", e);
        return null;
      });
      if (!member) return;

      const isWL =
        whitelistUsers.includes(executor.id) ||
        member.roles.cache.some(role => whitelistRoles.includes(role.id));

      const channel = logChannelId && ban.guild.channels.cache.get(logChannelId);
      if (!channel?.send) return;

      const embed = new EmbedBuilder()
        .setColor(isWL ? "#00b0f4" : "#ff0000")
        .setTitle(isWL ? "Whitelisted Ban Detected" : "Unauthorized Ban")
        .setDescription(
          `**${executor.tag}** (${executor.id}) banned **${ban.user.tag}** (${ban.user.id})` +
          (isWL ? `\n\n> No action taken (User is whitelisted).` : `\n\n> Executor has been banned.`)
        )
        .setTimestamp();

      if (!isWL) {
        await ban.guild.members.ban(executor.id, {
          reason: "Unauthorized ban"
        }).catch(e => console.error("Failed to ban executor:", e));
      }

      await channel.send({ embeds: [embed] }).catch(e => console.error("Failed to send log:", e));

    } catch (e) {
      console.error("[ANTINUKE] guildBanAdd error:", e);
    }
  },
};
