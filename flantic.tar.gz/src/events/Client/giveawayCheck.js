const Giveaway = require('../../schema/giveaway');
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'ready',
    async run(client) {
        setInterval(async () => {
            const giveaways = await Giveaway.find({ ended: false });

            for (const giveaway of giveaways) {
                if (Date.now() >= giveaway.endAt) {
                    giveaway.ended = true;
                    await giveaway.save();

                    const channel = client.channels.cache.get(giveaway.channelId);
                    if (!channel) continue;

                    try {
                        const message = await channel.messages.fetch(giveaway.messageId);
                        const reactions = message.reactions.cache.get('🎉');
                        if (!reactions) continue;

                        const users = (await reactions.users.fetch()).filter(u => !u.bot);
                        if (users.size === 0) {
                            const noWinEmbed = new EmbedBuilder()
                                .setTitle('🎉 Giveaway Ended!')
                                .setDescription(`No valid entries for **${giveaway.prize}**.`)
                                .setColor('Red');

                            await message.edit({ embeds: [noWinEmbed] });
                            continue;
                        }

                        const winner = users.random();
                        const winEmbed = new EmbedBuilder()
                            .setTitle('🎉 Giveaway Ended!')
                            .setDescription(`**Prize:** ${giveaway.prize}\nWinner: ${winner}`)
                            .setColor('Green');

                        await message.edit({ embeds: [winEmbed] });
                        channel.send(`🎉 Congratulations ${winner}! You won **${giveaway.prize}**!`);
                    } catch (err) {
                        console.error(`Error ending giveaway: ${err}`);
                    }
                }
            }
        }, 5000);
    }
};
