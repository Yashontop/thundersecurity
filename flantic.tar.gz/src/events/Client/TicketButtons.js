const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionFlagsBits } = require("discord.js");
const { TicketSetup, TicketData } = require("../../schema/ticket");

module.exports = {
  name: "interactionCreate",
  run: async (client, interaction) => {
    if (!interaction.isButton()) return;

    try {
      // CREATE TICKET
      if (interaction.customId === "create_ticket") {
        const setup = await TicketSetup.findOne({ guildId: interaction.guild.id, channelId: interaction.channel.id });
        if (!setup) {
          return interaction.reply({ content: "⚠️ Ticket setup not found for this panel.", ephemeral: true });
        }

        const existing = await TicketData.findOne({ guildId: interaction.guild.id, ownerId: interaction.user.id, closed: false });
        if (existing) {
          return interaction.reply({ content: "⚠️ You already have an open ticket.", ephemeral: true });
        }

        // Build permission overwrites — fully hidden from everyone else
        let overwrites = [
          {
            id: interaction.guild.id, // @everyone
            deny: [PermissionFlagsBits.ViewChannel]
          },
          {
            id: interaction.user.id, // ticket creator
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
              PermissionFlagsBits.ReadMessageHistory
            ]
          }
        ];

        // If supportRoles exist, give them access
        if (setup.supportRoles && setup.supportRoles.length > 0) {
          setup.supportRoles.forEach(rid => {
            overwrites.push({
              id: rid,
              allow: [
                PermissionFlagsBits.ViewChannel,
                PermissionFlagsBits.SendMessages,
                PermissionFlagsBits.ReadMessageHistory
              ]
            });
          });
        }

        // Give all admins access
        interaction.guild.members.cache
          .filter(m => m.permissions.has(PermissionFlagsBits.Administrator))
          .forEach(admin => {
            overwrites.push({
              id: admin.id,
              allow: [
                PermissionFlagsBits.ViewChannel,
                PermissionFlagsBits.SendMessages,
                PermissionFlagsBits.ReadMessageHistory
              ]
            });
          });

        // Create ticket channel
        const ticketChannel = await interaction.guild.channels.create({
          name: `ticket-${interaction.user.username}`,
          type: ChannelType.GuildText,
          parent: setup.categoryId,
          permissionOverwrites: overwrites
        });

        await TicketData.create({
          guildId: interaction.guild.id,
          channelId: ticketChannel.id,
          ownerId: interaction.user.id
        });

        const embed = new EmbedBuilder()
          .setColor("#00FFFF")
          .setTitle("🎫 Ticket Created")
          .setDescription("Please describe your issue in detail.\nA staff member will assist you shortly.")
          .setFooter({ text: "Flantic Ticket" });

        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId("close_ticket_confirm")
            .setLabel("Close Ticket")
            .setStyle(ButtonStyle.Danger)
        );

        await ticketChannel.send({ content: `<@${interaction.user.id}>`, embeds: [embed], components: [row] });
        return interaction.reply({ content: `✅ Your ticket has been created: ${ticketChannel}`, ephemeral: true });
      }

      // CLOSE CONFIRMATION
      if (interaction.customId === "close_ticket_confirm") {
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("close_ticket").setLabel("Close").setStyle(ButtonStyle.Danger),
          new ButtonBuilder().setCustomId("cancel_close").setLabel("Cancel").setStyle(ButtonStyle.Secondary)
        );
        return interaction.reply({ content: "Are you sure you want to close this ticket?", components: [row] });
      }

      // CLOSE TICKET
      if (interaction.customId === "close_ticket") {
        await TicketData.updateOne({ channelId: interaction.channel.id }, { closed: true });
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("delete_ticket").setLabel("Delete").setStyle(ButtonStyle.Danger),
          new ButtonBuilder().setCustomId("reopen_ticket").setLabel("Reopen").setStyle(ButtonStyle.Success)
        );
        return interaction.channel.send({ content: "✅ Ticket closed.", components: [row] });
      }

      // REOPEN TICKET
      if (interaction.customId === "reopen_ticket") {
        await TicketData.updateOne({ channelId: interaction.channel.id }, { closed: false });
        return interaction.channel.send("🔓 Ticket reopened.");
      }

      // DELETE TICKET
      if (interaction.customId === "delete_ticket") {
        await interaction.channel.delete();
      }

      // CANCEL CLOSE
      if (interaction.customId === "cancel_close") {
        return interaction.message.delete();
      }

    } catch (error) {
      console.error("ticket button error:", error);
    }
  }
};
