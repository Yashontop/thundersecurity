/** @format
 *
 * Arrkiii By Ozuma xd
 * © 2024 Arrkiii Development
 *
 */
const {
  EmbedBuilder,
  PermissionsBitField,
  WebhookClient,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");
const db = require("../../schema/prefix.js");
const bl = require("../../schema/blacklist");
const IgnoreChannelModel = require("../../schema/ignorechannel");
const VoteBypassUserModel = require("../../schema/votebypassuser");
const db4 = require("../../schema/noprefix");
const MediaChannel = require("../../schema/mediachannel");
const Sticky = require("../../schema/sticky"); // Added Sticky schema
const cooldowns = new Map();

module.exports = {
  name: "messageCreate",
  run: async (client, message) => {
    if (message.author.bot) return;

    // === Sticky message auto-keep system ===
    try {
      if (message.guild) {
        const sticky = await Sticky.findOne({
          guildId: message.guild.id,
          channelId: message.channel.id
        });
        if (sticky) {
          // Ignore if sticky itself triggered this event
          if (sticky.messageId && message.id === sticky.messageId) {
            // do nothing
          } else {
            // Delete old sticky
            if (sticky.messageId) {
              const old = await message.channel.messages.fetch(sticky.messageId).catch(() => null);
              if (old?.deletable) await old.delete().catch(() => {});
            }
            // Re-post sticky
            const sent = await message.channel.send({ content: sticky.content }).catch(() => null);
            if (sent) {
              sticky.messageId = sent.id;
              await sticky.save().catch(() => {});
            }
          }
        }
      }
    } catch (err) {
      console.error("Sticky message error:", err);
    }

    // === MEDIA-ONLY CHANNEL SYSTEM ===
    try {
      const mediaData = await MediaChannel.findOne({ guildId: message.guild.id });
      if (mediaData && mediaData.channels.includes(message.channel.id)) {
        if (message.attachments.size === 0 && message.embeds.length === 0) {
          await message.delete().catch(() => {});
          const embed = new EmbedBuilder()
            .setColor("Yellow")
            .setTitle("📸 Media Only Channel")
            .setDescription(`❌ ${message.author}, this channel is configured for **media only**.\nPlease send an image, video, or embed.`);
          const warnMsg = await message.channel.send({ embeds: [embed] });
          setTimeout(() => warnMsg.delete().catch(() => {}), 5000);
          return;
        }
      }
    } catch (err) {
      console.error("MediaChannel check failed:", err);
    }

    let prefix = client.prefix;
    const ress = await db.findOne({ Guild: message.guildId });
    if (ress && ress.Prefix) prefix = ress.Prefix;

    const mention = new RegExp(`^<@!?${client.user.id}>( |)$`);
    if (message.content.match(mention)) {
      if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.SendMessages))
        return await message.author.send({ content: `I don't have **\`SEND_MESSAGES\`** permission in <#${message.channelId}>.` }).catch(() => null);

      if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.ViewChannel))
        return;

      if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.EmbedLinks))
        return await message.channel.send({ content: `I don't have **\`EMBED_LINKS\`** permission in <#${message.channelId}>.` }).catch(() => {});

      const embed = new EmbedBuilder()
        .setColor(client.color)
        .setDescription(`Hey ${message.author},\nMy Prefix here is: \`${prefix}\`\nServer ID: \`${message.guild.id}\`\n\nType **${prefix}help** to get the command list.`)
        .setThumbnail(message.guild.iconURL({ dynamic: true }))
        .setFooter({ text: `Made By Hacker`, iconURL: client.user.displayAvatarURL() });

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setLabel("Invite Me").setStyle(ButtonStyle.Link).setURL(client.config.links.invite),
        new ButtonBuilder().setLabel("Support").setStyle(ButtonStyle.Link).setURL(client.config.links.support)
      );

      await message.channel.send({ embeds: [embed], components: [row] }).catch(() => null);
    }

    const np = [];
    const npData = await db4.findOne({ userId: message.author.id, noprefix: true });
    if (npData) np.push(message.author.id);

    const regex = new RegExp(`^<@!?${client.user.id}>`);
    const pre = message.content.match(regex) ? message.content.match(regex)[0] : prefix;
    if (!np.includes(message.author.id)) {
      if (!message.content.startsWith(pre)) return;
    }

    const args =
      !np.includes(message.author.id)
        ? message.content.slice(pre.length).trim().split(/ +/)
        : message.content.startsWith(pre)
        ? message.content.slice(pre.length).trim().split(/ +/)
        : message.content.trim().split(/ +/);
    const commandName = args.shift().toLowerCase();

    const command =
      client.commands.get(commandName) ||
      client.commands.find(cmd => cmd.aliases && cmd.aliases.includes(commandName));

    if (!command) return;

    const blusers = await bl.findOne({ userId: message.author.id });
    if (blusers) {
      const embed = new EmbedBuilder()
        .setColor("Red")
        .setDescription(`🚫 You have been blacklisted from using the bot!`);
      const m = await message.channel.send({ embeds: [embed] }).catch(() => null);
      setTimeout(() => m.delete().catch(() => null), 5000);
      return;
    }

    if (!cooldowns.has(command.name)) {
      cooldowns.set(command.name, new Map());
    }

    const now = Date.now();
    const timestamps = cooldowns.get(command.name);
    const cooldownAmount = (command.cooldown || 3) * 1000;

    if (timestamps.has(message.author.id)) {
      const expirationTime = timestamps.get(message.author.id) + cooldownAmount;
      if (now < expirationTime) {
        const timeLeft = Math.round(expirationTime / 1_000);
        const cooldownEmbed = new EmbedBuilder()
          .setColor(client.color)
          .setDescription(`Please wait **<t:${timeLeft}:R>** before reusing the \`${command.name}\` command.`);
        return message.reply({ embeds: [cooldownEmbed] }).then((msg) => {
          const delayTime = expirationTime - now;
          setTimeout(() => msg.delete(), delayTime);
        });
      }
    }
    timestamps.set(message.author.id, now);
    setTimeout(() => cooldowns.delete(message.author.id), cooldownAmount);

    const isIgnored = await IgnoreChannelModel.findOne({
      guildId: message.guild.id,
      channelId: message.channel.id,
    });
    if (isIgnored) {
      const embed = new EmbedBuilder()
        .setColor(client.color)
        .setDescription(`⚠️ This channel is set to ignored channel.`);
      const ignoreMessage = await message.channel.send({ embeds: [embed] }).catch(() => null);
      setTimeout(() => ignoreMessage.delete().catch(() => {}), 3000);
      return;
    }

    if (command.voteonly) {
      const hasVoted = await client.topgg.hasVoted(message.author.id);
      const voteBypassUser = await VoteBypassUserModel.findOne({ userId: message.author.id });
      if (!hasVoted && !voteBypassUser) {
        const embed = new EmbedBuilder()
          .setColor(client.color)
          .setDescription(`__This Command Is Only For Our Voters So Vote Us Now By [Clicking Here](https://top.gg/bot/${client.user.id}/vote)__`);
        return message.channel.send({ embeds: [embed] }).catch(() => null);
      }
    }

    if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.SendMessages))
      return await message.author.send({ content: `I don't have **\`SEND_MESSAGES\`** permission in <${message.guild.name}> to execute this **\`${command.name}\`** command.` }).catch(() => {});

    if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.ViewChannel))
      return;

    if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.EmbedLinks))
      return await message.author.send({ content: `I don't have **\`EMBED_LINKS\`** permission in <#${message.guild.name}> to execute this **\`${command.name}\`** command.` }).catch(() => {});

    if (command.args && !args.length) {
      let reply = `You didn't provide any arguments, ${message.author}!`;
      if (command.usage) reply += `\nUsage: \`${prefix}${command.name} ${command.usage}\``;
      const embed = new EmbedBuilder().setColor(client.color).setDescription(reply);
      return message.channel.send({ embeds: [embed] }).catch(() => null);
    }

    if (command.botPerms) {
      if (!message.guild.members.me.permissions.has(PermissionsBitField.resolve(command.botPerms || []))) {
        const embed = new EmbedBuilder().setDescription(`I don't have **\`${command.botPerms}\`** permission in <#${message.channelId}> to execute this **\`${command.name}\`** command.`);
        return message.channel.send({ embeds: [embed] }).catch(() => null);
      }
    }

    if (command.userPerms) {
      if (!message.member.permissions.has(PermissionsBitField.resolve(command.userPerms || []))) {
        const embed = new EmbedBuilder().setColor(client.color).setDescription(`You don't have **\`${command.userPerms}\`** permission in <#${message.channelId}> to execute this **\`${command.name}\`** command.`);
        return message.channel.send({ embeds: [embed] }).catch(() => null);
      }
    }

    if (command.owner && message.author.id !== `${client.owner}`) {
      const ozuma = await client.users.fetch(`1201457314805330040`);
      const embed = new EmbedBuilder().setColor(client.color).setAuthor({
        name: `| Only ${ozuma.displayName} can use this cmds!`,
        iconURL: message.author.displayAvatarURL(),
      });
      return message.channel.send({ embeds: [embed] }).catch(() => null);
    }

    const player = client.manager.players.get(message.guild.id);
    if (command.player && !player) {
      return message.channel.send(`i'm not in any vc!`).catch(() => null);
    }
    if (command.inVoiceChannel && !message.member.voice.channelId) {
      const embed = new EmbedBuilder().setColor(client.color).setAuthor({
        name: `You are not in any VC`,
        iconURL: message.author.displayAvatarURL(),
        url: client.config.links.support,
      });
      return message.channel.send({ embeds: [embed] }).catch(() => null);
    }

    if (command.sameVoiceChannel) {
      if (message.guild.members.me.voice.channel) {
        if (message.guild.members.me.voice.channelId !== message.member.voice.channelId) {
          const embed = new EmbedBuilder().setColor(client.color).setAuthor({
            name: `You are not in the same VC`,
            iconURL: message.author.displayAvatarURL(),
            url: client.config.links.support,
          });
          return message.channel.send({ embeds: [embed] }).catch(() => null);
        }
      }
    }

    command.execute(message, args, client, prefix).catch((e) => {
      console.log(e);
    });

    if (command && command.execute) {
      const web = new WebhookClient({ url: client.config.Webhooks.cmdrun });
      const commandlog = new EmbedBuilder()
        .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
        .setColor(client.color)
        .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
        .setTimestamp()
        .setDescription(
          `Command Just Used In : \`${message.guild.name} | ${message.guild.id}\`\nCommand Used In Channel : \`${message.channel.name} | ${message.channel.id}\`\nCommand Name : \`${command.name}\`\nCommand Executor : \`${message.author.tag} | ${message.author.id}\`\nCommand Content : \`${message.content}\``
        );
      web.send({ embeds: [commandlog] });
    }
  },
};
