const { EmbedBuilder } = require("discord.js");
const { getSettings } = require("../../schema/welcomesystem");

module.exports = {
  name: "guildMemberAdd",
  run: async (client, member) => {
    if (!member || !member.guild) return;
    const guild = member.guild;
    console.log(`[guildMemberAdd] Member ${member.user.tag} joined guild ${guild.name} (${guild.id})`);
    try {
      const settings = await getSettings(guild.id || guild);
      if (!settings?.welcome?.enabled) {
        console.log(`[guildMemberAdd] Welcome disabled for guild ${guild.name} (${guild.id})`);
        return;
      }
      await client.util.sendWelcome(member, settings);
      console.log(`[guildMemberAdd] Sent welcome to ${member.user.tag} in guild ${guild.name}`);
    } catch (error) {
      console.log("guildMemberAdd error:", error);
    }
  },
};