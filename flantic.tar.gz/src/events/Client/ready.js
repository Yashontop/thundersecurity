/** @format */

const { prefix } = require("../../config.js");
const { ActivityType } = require("discord.js");

module.exports = {
  name: "ready",
  run: async (client) => {
    const owner = client.users.cache.get(client.owner);
    const user = client.guilds.cache.reduce((a, g) => a + g.memberCount, 0);

    client.logger.log(`Made By ${owner?.displayName || "Unknown"}`, "ready");
    client.logger.log(`${client.user.username} online!`, "ready");
    client.logger.log(
      `Ready on ${client.guilds.cache.size} servers, for a total of ${user} users`,
      "ready",
    );

    // ✅ Set only one clean, fixed status
    client.user.setActivity("?help | ?invite", {
      type: ActivityType.Listening,
    });
  },
};
