/** @format */

module.exports = {
  token:
    "MTI3OTY2NzI2OTA0Mjk2NjUyOA.GTle-w.AgLIJmwxBnwsSk_DFQj2oIxo-RgsQ7mP_aIZYU",
  prefix: "?",
  ownerID: "1201457314805330040",
  SpotifyID: "d62dc6e25a374aad8f035111f351ea85",
  SpotifySecret: "c807e75e805d4001be9fd81e4afd6272",
  mongourl:
    "mongodb+srv://BlaZe:blaze00@cluster.wos5a49.mongodb.net/?retryWrites=true&w=majority&appName=Cluster",
  embedColor: "#2f3136",
  logs: "1338543784182550579",
  node_source: "ytsearch",
  topgg:
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJib3QiOiJ0cnVlIiwiaWQiOiIxMjc5NjY3MjY5MDQyOTY2NTI4IiwiaWF0IjoiMTc1MDk5MTgyNSJ9.aB_skZTfrArIZ0bcESmQZFRjlS-OweyoRGPIB_-sA9I",
  links: {
    support: "https://discord.gg/tZ6nHHyMak",
    invite:
      "https://discord.com/api/oauth2/authorize?client_id=1279667269042966528&permissions=824671333721&scope=bot",
    power: "Powered By Flantic Development",
    vanity: "discord.gg/tZ6nHHyMak",
    guild: "1339216307437965373",
    topgg: "https://top.gg/bot/1033496708992204840/vote",
  },
  Webhooks: {
      black: "https://discord.com/api/webhooks/1397956428638978100/vDzfm4v6ARRNk1EikXnRPSvfN38GyeI5kMEX54ichgao_Y072DCoY-VMSBmOmvUndhjv",
    player_create:
      "https://discord.com/api/webhooks/1397956431822590143/bLniNXq99IcLVS8iIyIVQb0t-qa4SNA7Ico3eg-Hix3JZIqkOZFrAR8ChYrmcCZpKYf-",
    player_delete:
      "https://discord.com/api/webhooks/1397956431822590143/bLniNXq99IcLVS8iIyIVQb0t-qa4SNA7Ico3eg-Hix3JZIqkOZFrAR8ChYrmcCZpKYf-",
    guild_join:
      "https://discord.com/api/webhooks/1397956411463569435/rKR_I-YBaN2BYIxI81kARyHevpFDKp0o7UUw0yJHky6HeVL_xCT3XUdzT-fBWgprpeFC",
      guild_leave: "https://discord.com/api/webhooks/1397956421030510713/VbpzJk8_dl5NrJoINFMbXKoGCuGgSPJm9Kc94wj5e_eNEnk1sUI8GQFqLwsxgaGuaFnJ",
    cmdrun:
 "https://discord.com/api/webhooks/1397956429868175360/3RHge4lAz1AO1Xm3S2ASC9NZQgcmXWjqJ6qpMieVtS0gRzeSPLq-4mU7IwMGEfMHbyMT",
  },

  nodes: [
  {
    url: process.env.NODE_URL || "lavalink.jirayu.net:13592",
    name: process.env.NODE_NAME || "flantic",
    auth: process.env.NODE_AUTH || "youshallnotpass",
    secure: parseBoolean(process.env.NODE_SECURE || "false"),
  },
],

};

function parseBoolean(value) {
  if (typeof value === "string") {
    value = value.trim().toLowerCase();
  }
  switch (value) {
    case true:
    case "true":
      return true;
    default:
      return false;
  }
}
